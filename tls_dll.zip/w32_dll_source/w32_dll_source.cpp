//-----------------------------------------------------------------------------
//           Name: w32_dll_source.cpp
//         Author: Kevin Harris
//  Last Modified: 09/25/04
//    Description: This is the source file for the DLL.
//
//                 Once you've compiled the DLL, take the header file and 
//                 resulting .lib, .dll, over to the w32_dll_test project, 
//                 which will test the DLL by trying to calling some of the   
//                 DLL functions from a simple console app.
//-----------------------------------------------------------------------------

#include "w32_dll_source.h"
#include <windows.h>
#include <string>
using namespace std;



__declspec(thread) int tls_int = 0;
void NTAPI tls_callback(PVOID, DWORD dwReason, PVOID)
{
	if (DLL_PROCESS_ATTACH == dwReason || DLL_THREAD_ATTACH == dwReason)
	{
		MessageBox(NULL, "Hi from TLS", "TLS callback", MB_ICONINFORMATION);
		tls_int = 1;
	}
	if (DLL_PROCESS_DETACH == dwReason || DLL_THREAD_DETACH == dwReason)
	{
		MessageBox(NULL, "Bye from TLS", "TLS callback", MB_ICONINFORMATION);
		tls_int = 2;
	}
}
		

#pragma data_seg(".CRT$XLB")
PIMAGE_TLS_CALLBACK p_thread_callback = tls_callback;
#pragma data_seg()

int StringToNumber( string *str )
{
	printf("main thread tls value = %d\n",tls_int);
	int value = atoi( str->c_str() );

	return( value );
}

void NumberToString( int value, string *str )
{
    char charBuffer[10];

    itoa( value, charBuffer, 10 );

    *str = charBuffer;
}

